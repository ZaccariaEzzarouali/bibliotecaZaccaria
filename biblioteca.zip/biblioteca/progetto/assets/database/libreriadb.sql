drop DATABASE if EXISTS libreria;
create DATABASE libreria;
use libreria;

CREATE TABLE Users
(
    id_utente INT(100) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    username varchar(45) NOT NULL,
    password VARCHAR(100) NOT NULL,
    amministratore boolean 
);


CREATE TABLE Categorie
(
	categoria_id int(3) PRIMARY KEY NOT null,
	categoriadesc varchar(25)
);



CREATE TABLE Libri
(
	id_libro INT(3) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	titolo varchar(50) NOT NULL,
	autore varchar(30) NOT NULL,
	anno int(4),
	categoria_id int(3),
	img VARCHAR(50) NOT NULL,
	quantita INT(20),
	FOREIGN KEY(categoria_id) REFERENCES Categorie(categoria_id)
);

CREATE TABLE acquisti
(
	id_acquisto INT(3) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	titolo varchar(50),
	username VARCHAR(45),
	id_utente INT(100),
	FOREIGN KEY(id_utente) REFERENCES users(id_utente)
);

INSERT INTO users(id_utente, username, PASSWORD, amministratore) 
VALUES (1, 'zaccaria', '$2y$10$l4XTBKC9TU52ShElCALydeSiafKw8n5vDePd2kA6kbDFmP/1nZ/da', TRUE );




INSERT INTO Categorie(categoria_id,categoriadesc)
VALUES (001, 'Avventura');

INSERT INTO Categorie(categoria_id,categoriadesc)
VALUES (002, 'Fantascienza');

INSERT INTO Categorie(categoria_id,categoriadesc)
VALUES (003, 'Fantasy');

INSERT INTO Categorie(categoria_id,categoriadesc)
VALUES (004, 'Horror');

INSERT INTO Categorie(categoria_id,categoriadesc)
VALUES (005, 'Racconti');



INSERT INTO Libri( titolo, autore,  anno, categoria_id, img, quantita)
VALUES ( 'Un anno', 'Emilio Lussu', 1997, 001, 'Un anno.jpg', 20);

INSERT INTO Libri( titolo, autore,  anno, categoria_id, img, quantita)
VALUES ( 'La nocchiera', 'Licia Troisi', 2005, 002, 'Poe.jpg' ,20 );

INSERT INTO Libri( titolo, autore,  anno, categoria_id, img, quantita)
VALUES ( 'La Botique', 'Dino Buzzati', 2002, 003, 'La botique.jpg', 1);

INSERT INTO Libri( titolo, autore,  anno, categoria_id, img, quantita)
VALUES ( 'Let the game begin', 'Kira shell', 1997, 004, 'Let the game begin.jpg', 20);

INSERT INTO Libri( titolo, autore,  anno, categoria_id, img, quantita)
VALUES ( 'Rancore', 'Enrico Carofiglio',  2003, 005, 'Rancore.jpg', 20);





















