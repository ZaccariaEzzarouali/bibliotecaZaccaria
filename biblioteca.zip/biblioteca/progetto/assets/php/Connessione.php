<?php 
class MysqlClass {
	public static function Connetti() {
		try {
			$host = "localhost";
			$dataBase = "libreria";
			$uid = "root";
			$pwd = "";
			$connessione = new PDO("mysql:host=$host;dbname=$dataBase", $uid, $pwd);
			} catch (PDOException $e) {
				return NULL;
			}
		return $connessione;
		}
	}
?>