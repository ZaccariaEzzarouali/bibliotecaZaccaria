<?php
 session_start();

if (!isset($_SESSION["loggedIn"]) || $_SESSION["loggedIn"] == false) {
    header("Location: login.php");
}
    include 'Connessione.php';
$link = MysqlClass::Connetti();

$id = $_POST['ciao'];

$sqlcontrollo = "SELECT quantita from libri where id_libro = $id";
$stmtcontrollo = $link->prepare($sqlcontrollo);
$stmtcontrollo->execute();
$fetch = $stmtcontrollo->fetch();
$quantita=$fetch['quantita'];
if($quantita <= 0){
    
    $remove = " DELETE FROM libri WHERE id_libro = :id_libro ;";
    $stmtremove = $link->prepare($remove);
$stmtremove->bindParam(":id_libro", $id);
$stmtremove->execute();
    echo "<script>alert('Libro non piu disponibile');</script>";

}else{

$user = $_SESSION['username'];
  $sql =  "INSERT INTO acquisti( titolo, username, id_utente) VALUES( (SELECT titolo from libri where id_libro = $id), '$user', (SELECT id_utente from users where username = '$user'))";
        $stmt = $link->prepare($sql);

if ($stmt->execute()) {        
        if ($stmt->execute()) {
            $sqlupdate = "UPDATE libri SET quantita=quantita-1 WHERE id_libro='$id';";
            $update = $link->prepare($sqlupdate);
            $update->execute();
            echo "<script>alert('Libro comprato');</script>";
        } else {
            print_r($stmt->errorInfo());
        }
    
}}


?>