<?php

session_start();

include 'Connessione.php';
$link = MysqlClass::Connetti();

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql1 = "SELECT id_utente, username, password FROM users WHERE username = :username and amministratore = '1' ";
    $stmt1 = $link->prepare($sql1);
    $stmt1->bindParam(":username", $username);
    
    $sql = "SELECT id_utente, username, password FROM users WHERE username = :username";
    $stmt = $link->prepare($sql);
    $stmt->bindParam(":username", $username);
    
    if ($stmt->execute()) {
        if ($stmt->rowCount() == 1) {
            
            if ($row = $stmt->fetch()) {
                $username = $row["username"];
                $hashed_password = $row["password"];
    
                if (password_verify($password, $hashed_password)) {
                    $_SESSION["loggedIn"] = true;
                    $_SESSION["username"] = $username;
                    header("Location: Biblioteca.php");
                    $stmt1->execute();
                    if ($stmt1->rowCount() == 1){
                        $_SESSION["amministratore"] = true;
                        header("Location: admin.php"); }
                } else {
                    echo ("password errata");
                    $_SESSION["loggedIn"] = false;
                }
            }
        } else {
            echo ("Credenziali errate: Utente non trovato.");
        }
    
    } else {
        print_r($stmt->errorInfo());
    }





/*$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT id_utente, username, password FROM users WHERE username = :username";
$stmt = $link->prepare($sql);
$stmt->bindParam(":username", $username);

if ($stmt->execute()) {
    if ($stmt->rowCount() == 1) {
        
        if ($row = $stmt->fetch()) {
            $username = $row["username"];
            $hashed_password = $row["password"];

            if (password_verify($password, $hashed_password)) {
                $_SESSION["loggedIn"] = true;
                $_SESSION["username"] = $username;
                echo("Utente riconosciuto correttamente");
            } else {
                echo ("popassword errata");
            }
        }
    } else {
        echo ("Credenziali errate: Utente non trovato.");
    }
} else {
    print_r($stmt->errorInfo());
}*/


?>