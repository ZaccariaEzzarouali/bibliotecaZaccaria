<?php
session_start();


if (!isset($_SESSION["loggedIn"]) || $_SESSION["loggedIn"] == false || $_SESSION["amministratore"] != true) {
    header("Location: login.php");
}

include 'Connessione.php';
$link = MysqlClass::Connetti();


$titolo = $_POST['titolo'];
$autore = $_POST['autore'];
$anno = $_POST['anno'];
$categoria_id = $_POST['categoria_id'];
$quantita = $_POST['quantita'];
$img = $_POST['img'];
if(isset($_POST['aggiungi'])){
$sql = "SELECT titolo FROM libri WHERE titolo = :titolo";
$stmt = $link->prepare($sql);
$stmt->bindParam(":titolo", $titolo);

if ($stmt->execute()) {
    if ($stmt->rowCount() == 1) {
        echo("titolo gia' in uso.");
    } else {
        
        $sql = " INSERT INTO libri (titolo, autore, anno, categoria_id, img, quantita) VALUES (:titolo, :autore, :anno, :categoria_id, :img, :quantita)";
        $stmt = $link->prepare($sql);
        
        $stmt->bindParam(":titolo", $titolo);
        $stmt->bindParam(":autore", $autore);
        $stmt->bindParam(":anno", $anno);
        $stmt->bindParam(":categoria_id", $categoria_id);
        $stmt->bindParam(":img", $img);
        $stmt->bindParam(":quantita", $quantita);
        

        if ($stmt->execute()) {
            echo "<script>alert('Libro aggiunto');</script>";
        } else {
            print_r($stmt->errorInfo());
        }
    }
}
}else {
     if(isset($_POST['elimina'])){
        $sql = "SELECT titolo FROM libri WHERE titolo = :titolo";
        $stmt = $link->prepare($sql);
        $stmt->bindParam(":titolo", $titolo);
        
        if ($stmt->execute()) {
            if ($stmt->rowCount() == 1) {
                $sql = " DELETE FROM libri WHERE titolo = :titolo ;";
                $stmt = $link->prepare($sql);
            $stmt->bindParam(":titolo", $titolo);
                if ($stmt->execute()) {
                    echo "<script>alert('libro eliminato');</script>";
                } else {
                    print_r($stmt->errorInfo());
                }
            } else {
                echo "<script>alert('Errore: Libro non esistente');</script>";
            }
         
            }
        }
     }
 

?>