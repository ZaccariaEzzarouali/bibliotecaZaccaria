<?php

include 'Connessione.php';
$link = MysqlClass::Connetti();
$username = $_POST['username'];
$password = $_POST['password'];
$confpass = $_POST['Cpassword'];
if($password==$confpass){
$sql = "SELECT id_utente FROM users WHERE username = :username";
$stmt = $link->prepare($sql);
$stmt->bindParam(":username", $username);

if ($stmt->execute()) {
    if ($stmt->rowCount() == 1) {
        echo("Username gia' in uso.");
    } else {
        $sql = " INSERT INTO users (username, password) VALUES (:username, :password)";
        $stmt = $link->prepare($sql);
        
        $password_hashed = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $password_hashed);
        
        if ($stmt->execute()) {
            echo "<script>alert('Lossgo');</script>";
            header("Location: login.php");
        } else {
            print_r($stmt->errorInfo());
        }
    }
} else {
    print_r($stmt->errorInfo());
}
}else{
    echo("Le password non corrispondono.");
}

?>