<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>About us - Brand</title>
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css?h=0fcf6cd17225a7cbc698825eee09999a">
        <link rel="stylesheet" href="../css/styles.min.css?h=81b792daa31b64208eb6d3aee97bf73e"></head>
    <body style="background:linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('../img/Libreria.jpg');">
        <h1 class="text-center text-white d-none d-lg-block site-heading">
            <span class="site-heading-lower">Libreria del Castello Admin</span>
        </h1>
        <nav class="navbar navbar-dark navbar-expand-lg bg-dark py-lg-4" id="mainNav">
            <div class="container">
                <a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Brand</a>
                <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navbarResponsive">
                    <span class="visually-hidden">Toggle navigation</span>
                    <span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav mx-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="../../index.html">Home</a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </nav>
            <section class="page-section clearfix">
                    <div class="container">
                        <div class="intro">
                            <div class="text-center intro-text p-5 rounded bg-faded">
                                <h2 class="section-heading mb-4">
                                    <span class="section-heading-lower">Login</span>
                                </h2>
                               <form action="admininsert.php" method="POST">
      <div class='mb-3 row'>
          <input type="text" name= "titolo" placeholder="titolo" required="">
      </div>
      <div class='mb-3 row'>
          <input type="text" name= "autore" placeholder="autore">
      </div>
      <div class='mb-3 row'>
          <input type="text" name= "anno" placeholder="anno" >
      </div>
      <div class='mb-3 row'>
          <input type="text" name= "categoria_id" placeholder="categoria_id">
      </div>
      <div class='mb-3 row'>
          <input type="text" name= "img" placeholder="url immagine con estensione">
      </div>
      <div class='mb-3 row'>
          <input type="text" name= "quantita" placeholder="quantita">
      </div>
      <br></br>
      <div class="mx-auto intro-button">
                                    <input type="submit" name='aggiungi' class="btn btn-primary d-inline-block mx-auto btn-xl"></input>
                                    <br></br>
      <div class="button">
                                    <button type="submit" name='elimina' >elimina</input>
                            </form>
                            
                            </div>
                        </div>
                    </div>
                </section>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script src="../js/script.min.js?h=2b73f98f110c7c604b36df54dc174798"></script>
        </body>
        </html>