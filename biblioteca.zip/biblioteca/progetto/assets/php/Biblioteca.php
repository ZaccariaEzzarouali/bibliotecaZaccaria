<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>About us - Brand</title>
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css?h=0fcf6cd17225a7cbc698825eee09999a">
        <link rel="stylesheet" href="../css/styles.min.css?h=81b792daa31b64208eb6d3aee97bf73e"></head>
    <body style="background:linear-gradient(rgba(47, 23, 15, 0.65), rgba(47, 23, 15, 0.65)), url('../img/Libreria.jpg');">
        <h1 class="text-center text-white d-none d-lg-block site-heading">
            <span class="site-heading-lower">Libreria del Castello</span>
        </h1>
        <nav class="navbar navbar-dark navbar-expand-lg bg-dark py-lg-4" id="mainNav">
            <div class="container">
                <a class="navbar-brand text-uppercase d-lg-none text-expanded" href="#">Brand</a>
                <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navbarResponsive">
                    <span class="visually-hidden">Toggle navigation</span>
                    <span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav mx-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="../../index.html">Home</a>
                            </li>
                                    <li class="nav-item" ><a class="nav-link" href="../../Negozio.html" >
                                        Negozio
                                    </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../About.html">About</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="login.php">Login</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <section class="page-section about-heading">
                <form action=Biblioteca.php method='POST'> 
                <div class="container">
                    <div class="about-heading-content">
                        <div class="row">
                            <div class="col-lg-10 col-xl-9 mx-auto">
                                <div class="bg-faded rounded p-5">
                                    <h2 class="section-heading mb-4">Libri
                                    </h2>
                                    <div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
    Categoria
  </a>
  <br></br>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <li><button class="dropdown-item" name='all'>Tutti</a></li>
    <li><button class="dropdown-item" name='1'>Avventura</a></li>
    <li><button class="dropdown-item" name='2'>Fantascienza</a></li>
    <li><button class="dropdown-item" name='3'>Fantasy</a></li>
    <li><button class="dropdown-item" name='4'>Horror</a></li>
    <li><button class="dropdown-item" name="5">Racconti</a></li>
  </ul>
</div>
</form>

                                    <?php 
session_start();

include 'Connessione.php';
$link = MysqlClass::Connetti();
$id=0;
if(isset($_POST['1'])){
$id = 1;
}else if(isset($_POST['2'])){
    $id = 2;
}else if(isset($_POST['3'])){
    $id = 3;
}else if(isset($_POST['4'])){
    $id = 4;
}else if(isset($_POST['5'])){
    $id = 5;
}else if(isset($_POST['all'])){
    $id=0;
}
$sql = "SELECT id_libro, img, autore, titolo   FROM libri ";
if ($id!=0){$sql = "SELECT id_libro, img, autore, titolo   FROM libri where  categoria_id=$id";}
  
    $stmt = $link->prepare($sql);
    $stmt->execute();

    
    echo '<table border="0" cellspacing="2" cellpadding="15"> 
      <tr> 
          <td> <font face="Arial">Copertina</font> </td> 
          <td> <font face="Arial">Titolo</font> </td> 
          <td> <font face="Arial">autore</font> </td> 

      </tr>';

if ($stmt->execute()) {
    while ($fetch = $stmt->fetch()) {

        echo '
        <form action="Acquisto.php" method="POST"><tr> 
        <td><img src="../img/libri/'.$fetch['img'].'"></td> 
         <td>'.$fetch['titolo'].'</td> 
        <td>'.$fetch['autore'].'</td> 
        <td><button type="submit" class="btn btn-primary" name="ciao" value="'.$fetch['id_libro'].'"height:200px;width:200px>ACQUISTA</button></td> 
        </form>
                  
              </tr>';
    }
} 
    
    
    
    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            </section>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script src="../js/script.min.js?h=2b73f98f110c7c604b36df54dc174798"></script>
        </body>
        </html>